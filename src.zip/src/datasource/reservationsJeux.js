
// JSON contenant les réservations de jeux dans la boutique par les différents utilisateurs

export const reservationsJeux = [
    {
        reservationJeuId: 1,
        jeuID: "01",
        userId: 12346,
        orderNumber: "5",
        prix: "15",
    },
    {
        reservationJeuId: 2,
        jeuID: "02",
        userId: 12346,
        orderNumber: "14",
        prix: "30",
    },
];