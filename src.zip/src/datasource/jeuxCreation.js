export const jeuxCreation = [

];