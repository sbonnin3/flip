
// JSON qui aurait dû contenir les données des jeux créés par les comptes créateur de jeux mais vide par manque de temps

export const jeuxCreation = [
];