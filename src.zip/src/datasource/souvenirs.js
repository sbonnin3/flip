
// JSON contenant les données des souvenirs dans la boutique

export const souvenirs = [
    {
        _id: '001',
        nom: 'Woopy',
        image: require('@/assets/images/souvenir_woopys.png'),
        prix: "1"
    },
    {
        _id: '002',
        nom: 'Chapeau de paille',
        image: require('@/assets/images/souvenir_chapeau.png'),
        prix: "2"
    },
    {
        _id: '003',
        nom: 'Aimant du festival',
        image: require('@/assets/images/souvenir_aimant_flip.png'),
        prix: "5"
    },
    {
        _id: '004',
        nom: 'Lunette Flip Up',
        image: require('@/assets/images/souvenir_lunette.png'),
        prix: "10"
    },
    {
        _id: '005',
        nom: 'Stylo personnalisable',
        image: require('@/assets/images/souvenir_stylo.png'),
        prix: "8"
    },
]