export default {
  namespaced: true,
  state: {
    tournois: require("@/datasource/data").tournois, // Charge les données initiales
  },
    mutations: {
      SET_TOURNOIS(state, tournois) {
        state.tournois = tournois;
      },
      ADD_TOURNOI(state, tournoi) {
        state.tournois.push(tournoi);
      },
      UPDATE_TOURNOI(state, { index, tournoi }) {
        state.tournois.splice(index, 1, tournoi);
      }
    },
    actions: {
      async getAllTournois({ commit }) {
        try {
          const { tournois } = await import("@/datasource/tournois");
          commit("SET_TOURNOIS", tournois);
        } catch (error) {
          console.error("Erreur chargement tournois:", error);
        }
      },
      async updateTournoi({ commit, state }, tournoi) {
        const index = state.tournois.findIndex(t => t._id === tournoi._id);
        if (index !== -1) {
          commit('UPDATE_TOURNOI', { index, tournoi });
          return tournoi;
        }
        throw new Error("Tournoi non trouvé");
      },
      async addTournoi({ commit }, tournoiData) {
        try {
          // Vérification des données requises
          if (!tournoiData.nom || !tournoiData.lieu || !tournoiData.prestataireId) {
            throw new Error("Données manquantes pour la création du tournoi");
          }
      
          // Formatage des données
          const formattedTournoi = {
            _id: Date.now().toString(), // ID unique
            nom: tournoiData.nom.trim(),
            lieu: tournoiData.lieu.trim(),
            prix: Number(tournoiData.prix) || 0,
            image: tournoiData.image || require('@/assets/images/default-tournoi.png'),
            description: tournoiData.description?.trim() || '',
            prestataireId: tournoiData.prestataireId,
            dates: this.formatDates(tournoiData.dates)
          };
      
          // Validation des dates
          if (!formattedTournoi.dates || formattedTournoi.dates.length === 0) {
            throw new Error("Au moins une date est requise");
          }
      
          // Ajout au store
          commit('ADD_TOURNOI', formattedTournoi);
          
          // Pour debug (à supprimer en production)
          console.log('Tournoi créé:', formattedTournoi);
          
          return formattedTournoi;
          
        } catch (error) {
          console.error("Erreur dans addTournoi:", error);
          throw error; // Propagation de l'erreur pour la gestion dans le composant
        }
      },
      
      // Méthode helper pour formater les dates (ajoutez-la dans le même module)
      formatDates(dates) {
        if (!Array.isArray(dates)) return [];
        
        return dates.map(date => ({
          jour: Number(date.jour) || 1,
          mois: Number(date.mois) || 1,
          annee: Number(date.annee) || new Date().getFullYear(),
          heures: Number(date.heures) || 0,
          min: Number(date.min) || 0,
          placesRestantes: Number(date.placesRestantes) || 0
        }));
      }
    },
    getters: {
        allTournoi: (state) => state.tournois || [],
      tournoisByUser: (state) => (userId) => {
        return state.tournois.filter(t => t.prestataireId === userId);
      }
    }
  };